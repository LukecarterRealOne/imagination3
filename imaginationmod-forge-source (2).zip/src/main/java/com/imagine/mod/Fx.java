package com.imagine.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/** Particle / sound / screen helpers. Everything the abilities draw goes through here. */
public final class Fx {
    private Fx() {}

    /** Particles visible from far away (normal particle spawning only reaches ~32 blocks). */
    public static void burst(ServerLevel sw, ParticleOptions e, double x, double y, double z,
                             int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayer p : sw.players()) {
            if (p.distanceToSqr(x, y, z) < 160 * 160) {
                sw.sendParticles(p, e, true, x, y, z, count, dx, dy, dz, speed);
            }
        }
    }

    public static void ring(ServerLevel sw, ParticleOptions e, double cx, double cy, double cz, double r, int pts) {
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts;
            burst(sw, e, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    /** Hollow sphere of particles (fibonacci spiral so it looks even). */
    public static void sphere(ServerLevel sw, ParticleOptions e, Vec3 c, double r, int pts, double spin) {
        for (int i = 0; i < pts; i++) {
            double y = 1 - 2.0 * (i + 0.5) / pts;
            double rr = Math.sqrt(Math.max(0, 1 - y * y));
            double a = i * 2.399963 + spin;
            burst(sw, e, c.x + Math.cos(a) * rr * r, c.y + y * r, c.z + Math.sin(a) * rr * r, 1, 0, 0, 0, 0);
        }
    }

    /** Vertical column of particles. */
    public static void column(ServerLevel sw, ParticleOptions e, Vec3 base, double h, double step, double spread) {
        for (double y = 0; y <= h; y += step) {
            burst(sw, e, base.x, base.y + y, base.z, 1, spread, 0, spread, 0);
        }
    }

    /** Rising spiral. */
    public static void spiral(ServerLevel sw, ParticleOptions e, Vec3 base, double r, double h, double turns, int pts, double spin) {
        for (int i = 0; i < pts; i++) {
            double f = i / (double) pts;
            double a = f * turns * Math.PI * 2 + spin;
            burst(sw, e, base.x + Math.cos(a) * r, base.y + f * h, base.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    /** Straight line of particles. */
    public static void line(ServerLevel sw, ParticleOptions e, Vec3 a, Vec3 b, double step) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 n = d.scale(1.0 / len);
        for (double t = 0; t <= len; t += step) {
            burst(sw, e, a.x + n.x * t, a.y + n.y * t, a.z + n.z * t, 1, 0, 0, 0, 0);
        }
    }

    /** Low, drifting, pale fog - the signature liminal look. */
    public static void fog(ServerLevel sw, Vec3 c, double radius, int count) {
        burst(sw, ParticleTypes.WHITE_ASH, c.x, c.y, c.z, count, radius, radius * 0.3, radius, 0);
        burst(sw, ParticleTypes.CLOUD, c.x, c.y - radius * 0.2, c.z, Math.max(1, count / 4), radius, radius * 0.15, radius, 0);
    }

    public static void sound(ServerLevel sw, BlockPos pos, SoundEvent s, float vol, float pitch) {
        sw.playSound(null, pos, s, SoundSource.PLAYERS, vol, pitch);
    }

    /** Screen flash + camera shake for nearby players. */
    public static void screen(ServerLevel sw, Vec3 pos, double radius, float flash, float shake, int duration, int color) {
        for (ServerPlayer p : sw.players()) {
            if (p.distanceToSqr(pos) < radius * radius) {
                ImaginationMod.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                        new FxPacket(flash, shake, duration, color));
            }
        }
    }
}
