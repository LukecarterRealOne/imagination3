package com.imagine.mod;

import net.minecraft.util.Mth;

/** The six modes (same order as the ability categories) and the colour each one glows. */
public final class Modes {
    private Modes() {}

    public static final int DREAM = 0, LIMINAL = 1, CREATION = 2, REALITY = 3, NIGHTMARE = 4, WONDER = 5;

    public static float[] hsv(float hue, float sat, float val) {
        int c = Mth.hsvToRgb(hue - (float) Math.floor(hue), sat, val);
        return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
    }

    /** Glow colour of a mode at time t (ticks). Liminal drifts through sickly yellows, Wonder cycles the rainbow. */
    public static float[] rgb(int mode, float t) {
        switch (mode) {
            case DREAM:
                return new float[]{1f, 0.72f, 0.88f};
            case LIMINAL:
                return hsv(0.14f + 0.08f * Mth.sin(t * 0.03f), 0.55f, 1f);
            case CREATION:
                return new float[]{0.7f, 1f, 0.85f};
            case REALITY:
                return new float[]{0.62f, 0.72f, 1f};
            case NIGHTMARE:
                return new float[]{0.38f, 0.1f, 0.6f};
            default:
                return hsv(t * 0.01f, 0.6f, 1f);
        }
    }
}
