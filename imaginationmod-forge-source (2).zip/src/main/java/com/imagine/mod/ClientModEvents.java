package com.imagine.mod;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ImaginationMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping OPEN_MENU = new KeyMapping("key.imaginationmod.menu",
            InputConstants.Type.KEYSYM, 71, "key.categories.imaginationmod"); // 71 = G
    public static final KeyMapping OPEN_MENU_B = new KeyMapping("key.imaginationmod.menu_b",
            InputConstants.Type.KEYSYM, 66, "key.categories.imaginationmod"); // 66 = B
    public static final KeyMapping CAST = new KeyMapping("key.imaginationmod.cast",
            InputConstants.Type.KEYSYM, 82, "key.categories.imaginationmod"); // 82 = R

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_MENU);
        event.register(OPEN_MENU_B);
        event.register(CAST);
    }

    /** Put the glow / face-effect layer on every player skin type (classic + slim arms). */
    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : event.getSkins()) {
            EntityRenderer<? extends Player> renderer = event.getSkin(skin);
            if (renderer instanceof PlayerRenderer pr) {
                pr.addLayer(new ModeLayer(pr));
            }
        }
    }
}
