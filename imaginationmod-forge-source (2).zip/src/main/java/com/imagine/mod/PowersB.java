package com.imagine.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Creation (19-33) and Reality (34-46). */
public final class PowersB {
    private PowersB() {}

    // ───────────────────────── shared builders ─────────────────────────

    private interface PathState {
        BlockState at(int step, int lane);
    }

    /** Grows a path of temporary blocks in front of the player, slice by slice. */
    private static void path(ServerLevel sw, Player u, int length, int half, boolean rise, int perTick, int life, PathState st) {
        final Vec3 dir = Util.flatLook(u);
        final Vec3 side = new Vec3(-dir.z, 0, dir.x);
        final Vec3 base = u.position();
        final int floorY = Mth.floor(u.getY()) - 1;
        for (int i = 1; i <= length; i++) {
            final int step = i;
            Scheduler.later(step / perTick + 1, () -> {
                int y = floorY + (rise ? step / 2 : 0);
                Map<BlockPos, BlockState> slice = new LinkedHashMap<>();
                for (int k = -half; k <= half; k++) {
                    Vec3 p = base.add(dir.scale(step)).add(side.scale(k));
                    slice.put(BlockPos.containing(p.x, y, p.z), st.at(step, k));
                }
                TempBlocks.placeAll(sw, slice, life);
                Vec3 e = base.add(dir.scale(step));
                Fx.burst(sw, Pal.DREAM, e.x, y + 1.2, e.z, 4, 1, 0.2, 1, 0);
                Fx.burst(sw, ParticleTypes.END_ROD, e.x, y + 1.0, e.z, 2, 0.8, 0.1, 0.8, 0.01);
            });
        }
    }

    // ───────────────────────── CREATION ─────────────────────────

    static void phantomBlades(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, 2f, 1.4f);
        Util.loop(100, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1.2, 0);
            for (int b = 0; b < 8; b++) {
                double a = t * 0.22 + b * Math.PI / 4;
                double bx = mid.x + Math.cos(a) * 2.6;
                double bz = mid.z + Math.sin(a) * 2.6;
                for (double h = -0.7; h <= 0.7; h += 0.35) {
                    Fx.burst(sw, ParticleTypes.END_ROD, bx, mid.y + h, bz, 1, 0, 0, 0, 0);
                }
                Fx.burst(sw, Pal.LAVENDER, bx, mid.y + 0.9, bz, 1, 0.05, 0.05, 0.05, 0);
            }
            if (t % 5 == 0) {
                for (Mob m : Util.foes(sw, mid, 3.6)) {
                    Util.hurt(sw, u, m, 6f);
                    Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, m.getX(), m.getY() + 1, m.getZ(), 10, 0.3, 0.4, 0.3, 0.3);
                }
            }
        });
    }

    static void imagineBridge(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 1.0f);
        path(sw, u, 24, 1, false, 1, 300, (s, k) -> Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState());
    }

    static void imagineStaircase(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 1.4f);
        path(sw, u, 28, 1, true, 1, 300, (s, k) -> Blocks.WHITE_STAINED_GLASS.defaultBlockState());
    }

    static void imagineWall(ServerLevel sw, Player u) {
        Vec3 dir = Util.flatLook(u);
        Vec3 side = new Vec3(-dir.z, 0, dir.x);
        Vec3 mid = u.position().add(dir.scale(3));
        int y0 = Mth.floor(u.getY());
        Map<BlockPos, BlockState> wall = new LinkedHashMap<>();
        for (int k = -4; k <= 4; k++) {
            for (int h = 0; h < 5; h++) {
                Vec3 p = mid.add(side.scale(k));
                wall.put(BlockPos.containing(p.x, y0 + h, p.z), Blocks.PINK_STAINED_GLASS.defaultBlockState());
            }
        }
        TempBlocks.placeAll(sw, wall, 200);
        Fx.sound(sw, u.blockPosition(), SoundEvents.GLASS_BREAK, 1.5f, 1.8f);
        Util.loop(10, 1, t -> {
            for (int k = -4; k <= 4; k++) {
                Vec3 p = mid.add(side.scale(k));
                Fx.burst(sw, Pal.PINK, p.x, y0 + t * 0.5, p.z, 2, 0.2, 0.1, 0.2, 0);
            }
        });
    }

    static void imagineTower(ServerLevel sw, Player u) {
        final int bx = u.blockPosition().getX();
        final int by = u.blockPosition().getY();
        final int bz = u.blockPosition().getZ();
        u.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 500, 0));
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_POWER_SELECT, 2f, 1.5f);
        for (int i = 0; i < 12; i++) {
            final int step = i;
            Scheduler.later(i + 1, () -> {
                if (Util.gone(sw, u)) return;
                Map<BlockPos, BlockState> one = new LinkedHashMap<>();
                one.put(new BlockPos(bx, by - 1 + step, bz), Blocks.WHITE_CONCRETE.defaultBlockState());
                TempBlocks.placeAll(sw, one, 400);
                Util.tp(u, bx + 0.5, by + step, bz + 0.5);
                Util.launch(u, 0, 0, 0);
                Fx.ring(sw, ParticleTypes.END_ROD, bx + 0.5, by + step, bz + 0.5, 1.2, 14);
                Fx.burst(sw, Pal.CREAM, bx + 0.5, by + step, bz + 0.5, 6, 0.5, 0.1, 0.5, 0);
            });
        }
    }

    static void imagineDome(ServerLevel sw, Player u) {
        BlockPos c = u.blockPosition();
        Map<BlockPos, BlockState> shell = new LinkedHashMap<>();
        for (int dx = -6; dx <= 6; dx++) {
            for (int dy = -1; dy <= 6; dy++) {
                for (int dz = -6; dz <= 6; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d >= 4.4 && d <= 5.4) shell.put(c.offset(dx, dy, dz), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState());
                }
            }
        }
        TempBlocks.placeAll(sw, shell, 400);
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_ACTIVATE, 2f, 1.2f);
        Util.loop(20, 1, t -> Fx.sphere(sw, ParticleTypes.END_ROD, u.position().add(0, 1, 0), 0.5 + t * 0.25, 30, t * 0.2));
    }

    static void imagineSun(ServerLevel sw, Player u) {
        final List<Vec3> orbs = new ArrayList<>();
        Map<BlockPos, BlockState> lights = new LinkedHashMap<>();
        for (int i = 0; i < 6; i++) {
            double a = Math.PI * 2 * i / 6;
            Vec3 p = u.position().add(Math.cos(a) * 6, 3 + sw.random.nextInt(4), Math.sin(a) * 6);
            BlockPos bp = BlockPos.containing(p.x, p.y, p.z);
            lights.put(bp, Blocks.LIGHT.defaultBlockState());
            orbs.add(new Vec3(bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5));
        }
        TempBlocks.placeAll(sw, lights, 2400);
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_ACTIVATE, 2f, 1.8f);
        Util.loop(200, 4, t -> {
            for (Vec3 o : orbs) {
                Fx.burst(sw, Pal.YELLOW, o.x, o.y, o.z, 3, 0.25, 0.25, 0.25, 0);
                Fx.burst(sw, ParticleTypes.END_ROD, o.x, o.y, o.z, 1, 0.3, 0.3, 0.3, 0.01);
            }
        });
    }

    static void imagineGarden(ServerLevel sw, Player u) {
        BlockPos c = u.blockPosition();
        for (int dx = -7; dx <= 7; dx++) {
            for (int dz = -7; dz <= 7; dz++) {
                for (int dy = -2; dy <= 2; dy++) {
                    if (dx * dx + dz * dz > 49 || sw.random.nextInt(3) != 0) continue;
                    BlockPos p = c.offset(dx, dy, dz);
                    if (BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL, 8), sw, p, u)) {
                        Fx.burst(sw, ParticleTypes.HAPPY_VILLAGER, p.getX() + 0.5, p.getY() + 1, p.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0);
                    }
                }
            }
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 2f, 1.5f);
        Util.loop(16, 1, t -> {
            Fx.ring(sw, Pal.MINT, u.getX(), u.getY() + 0.2, u.getZ(), 1 + t * 0.5, 36);
            Fx.burst(sw, ParticleTypes.SPORE_BLOSSOM_AIR, u.getX(), u.getY() + 1, u.getZ(), 6, 5, 1.5, 5, 0);
        });
    }

    static void imagineFeast(ServerLevel sw, Player u) {
        u.getFoodData().eat(20, 1.0f);
        u.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        Fx.sound(sw, u.blockPosition(), SoundEvents.PLAYER_LEVELUP, 1.5f, 1.6f);
        final Item[] foods = {Items.CAKE, Items.GOLDEN_APPLE, Items.GOLDEN_CARROT, Items.COOKIE, Items.PUMPKIN_PIE};
        Util.loop(30, 1, t -> {
            if (Util.gone(sw, u)) return;
            for (int i = 0; i < 2; i++) {
                Item f = foods[sw.random.nextInt(foods.length)];
                Fx.burst(sw, new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(f)),
                        u.getX() + (sw.random.nextDouble() - 0.5) * 3, u.getY() + 0.5 + t * 0.07,
                        u.getZ() + (sw.random.nextDouble() - 0.5) * 3, 3, 0.2, 0.2, 0.2, 0.05);
            }
            Fx.burst(sw, Pal.PINK, u.getX(), u.getY() + 1, u.getZ(), 2, 1, 1, 1, 0);
        });
    }

    private static final Set<String> BANNED_ITEMS = Set.of("air", "barrier", "command_block", "chain_command_block",
            "repeating_command_block", "command_block_minecart", "structure_block", "structure_void", "jigsaw",
            "debug_stick", "light", "knowledge_book", "bedrock", "spawner", "end_portal_frame", "reinforced_deepslate");

    static void imagineAnything(ServerLevel sw, Player u) {
        List<Item> pool = new ArrayList<>();
        for (Item it : ForgeRegistries.ITEMS) {
            ResourceLocation key = ForgeRegistries.ITEMS.getKey(it);
            if (key != null && !BANNED_ITEMS.contains(key.getPath())) pool.add(it);
        }
        if (pool.isEmpty()) return;
        final Vec3 c = u.position();
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 0.8f);
        for (int i = 0; i < 24; i++) {
            final Item chosen = pool.get(sw.random.nextInt(pool.size()));
            final Vec3 at = c.add((sw.random.nextDouble() - 0.5) * 10, 9, (sw.random.nextDouble() - 0.5) * 10);
            Scheduler.later(i * 2 + 1, () -> {
                Fx.burst(sw, ParticleTypes.END_ROD, at.x, at.y, at.z, 12, 0.3, 0.3, 0.3, 0.08);
                Fx.burst(sw, Pal.DREAM, at.x, at.y, at.z, 8, 0.4, 0.4, 0.4, 0);
                ItemEntity ie = new ItemEntity(sw, at.x, at.y, at.z, new ItemStack(chosen));
                ie.setDeltaMovement(0, -0.1, 0);
                sw.addFreshEntity(ie);
            });
        }
    }

    static void imagineArmor(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 4));
        u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1200, 1));
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_POWER_SELECT, 2f, 1.3f);
        Fx.screen(sw, u.position(), 24, 0.4f, 0f, 1, 0xFFF0C8);
        Util.loop(30, 1, t -> {
            Fx.spiral(sw, ParticleTypes.END_ROD, u.position(), 1.0, 2.2, 2, 24, t * 0.4);
            Fx.spiral(sw, Pal.CREAM, u.position(), 1.2, 2.2, 2, 24, -t * 0.4);
        });
    }

    static void imaginaryFriend(ServerLevel sw, Player u) {
        Vec3 spot = u.position().add(Util.flatLook(u).scale(2));
        Mob wolf = Util.ally(sw, u, EntityType.WOLF, spot, 1200, "\u00a7dImaginary Friend");
        if (wolf == null) return;
        wolf.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 1, false, false));
        Fx.sound(sw, u.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, 2f, 1.5f);
    }

    static void imaginaryArmy(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, 3f, 1.0f);
        Fx.screen(sw, u.position(), 30, 0.5f, 2f, 6, 0xF0E8FF);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8;
            Vec3 spot = u.position().add(Math.cos(a) * 4.5, 0.2, Math.sin(a) * 4.5);
            EntityType<?> type = (i % 2 == 0) ? EntityType.IRON_GOLEM : EntityType.SNOW_GOLEM;
            Util.ally(sw, u, type, spot, 1200, "\u00a7fImaginary Knight");
        }
        Util.loop(20, 1, t -> Fx.ring(sw, Pal.DREAM, u.getX(), u.getY() + 0.2 + t * 0.1, u.getZ(), 4.5, 40));
    }

    private static final BlockState[] RAINBOW = {
            Blocks.RED_STAINED_GLASS.defaultBlockState(), Blocks.ORANGE_STAINED_GLASS.defaultBlockState(),
            Blocks.YELLOW_STAINED_GLASS.defaultBlockState(), Blocks.LIME_STAINED_GLASS.defaultBlockState(),
            Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), Blocks.BLUE_STAINED_GLASS.defaultBlockState(),
            Blocks.PURPLE_STAINED_GLASS.defaultBlockState()};

    static void rainbowBridge(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_TWINKLE, 2f, 1.0f);
        path(sw, u, 32, 3, false, 2, 400, (s, k) -> RAINBOW[k + 3]);
    }

    static void dreamMoon(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_ACTIVATE, 3f, 0.5f);
        for (var p : Util.playersNear(sw, u.position(), 20)) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false));
        }
        Util.loop(160, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 moon = u.position().add(0, 26, 0);
            Fx.sphere(sw, Pal.CREAM, moon, 6, 40, t * 0.02);
            if (t % 2 == 0) Fx.sphere(sw, ParticleTypes.END_ROD, moon, 6.3, 16, -t * 0.03);
            Fx.burst(sw, Pal.PINK, moon.x - 2, moon.y + 1, moon.z + 3, 2, 0.5, 0.5, 0.5, 0);
            if (t % 3 == 0) Fx.line(sw, ParticleTypes.END_ROD, moon.add(0, -6, 0), u.position().add(0, 2, 0), 2.0);
            if (t % 20 == 0) {
                for (var p : Util.playersNear(sw, u.position(), 14)) {
                    p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
                    Fx.burst(sw, ParticleTypes.HEART, p.getX(), p.getY() + 1.6, p.getZ(), 3, 0.4, 0.4, 0.4, 0);
                }
            }
        });
    }

    // ───────────────────────── REALITY ─────────────────────────

    static void gravityFlip(ServerLevel sw, Player u) {
        final List<Mob> victims = Util.foes(sw, u.position(), 12);
        Fx.sound(sw, u.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL, 2f, 0.5f);
        for (Mob m : victims) {
            Util.launch(m, 0, 1.4, 0);
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
        }
        Util.loop(20, 1, t -> {
            Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, u.getX(), u.getY() + 0.2 + t * 0.4, u.getZ(), 12 - t * 0.4, 40);
            for (Mob m : victims) {
                if (m.isAlive()) Fx.burst(sw, Pal.LAVENDER, m.getX(), m.getY() + 1, m.getZ(), 3, 0.3, 0.5, 0.3, 0);
            }
        });
        Scheduler.later(18, () -> {
            for (Mob m : victims) {
                if (m.isAlive()) {
                    Util.launch(m, 0, -3.0, 0);
                    Util.hurt(sw, u, m, 10f);
                }
            }
            Fx.sound(sw, u.blockPosition(), SoundEvents.GENERIC_EXPLODE, 1.5f, 0.6f);
            Fx.screen(sw, u.position(), 30, 0.3f, 3f, 6, 0xE8E0FF);
        });
    }

    static void warpPull(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.PORTAL_AMBIENT, 3f, 0.4f);
        Util.loop(30, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1, 0);
            for (Mob m : Util.foes(sw, mid, 18)) Util.pull(m, mid, 0.8);
            Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, mid.x, mid.y, mid.z, 18 - t * 0.55, 48);
            Fx.ring(sw, Pal.VOID, mid.x, mid.y + 0.5, mid.z, 16 - t * 0.5, 36);
        });
    }

    static void realityShove(ServerLevel sw, Player u) {
        final Vec3 c = u.position();
        Fx.sound(sw, u.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, 2f, 1.2f);
        Fx.screen(sw, c, 30, 0.4f, 3f, 6, 0xFFFFFF);
        for (Mob m : Util.foes(sw, c, 10)) {
            Util.hurt(sw, u, m, 10f);
            Util.shove(m, c, 2.0, 0.5);
        }
        Util.loop(12, 1, t -> {
            Fx.ring(sw, Pal.WHITE, c.x, c.y + 0.3, c.z, 1 + t * 0.9, 48);
            Fx.ring(sw, ParticleTypes.SONIC_BOOM, c.x, c.y + 1, c.z, 1 + t * 0.9, 8);
        });
    }

    static void stillness(ServerLevel sw, Player u) {
        final List<Mob> frozen = new ArrayList<>();
        for (Mob m : Util.foes(sw, u.position(), 16)) {
            if (!m.isNoAi()) {
                m.setNoAi(true);
                frozen.add(m);
            }
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 3f, 0.5f);
        Fx.screen(sw, u.position(), 30, 0.5f, 0f, 1, 0xDDE8F0);
        Util.loop(100, 1, t -> {
            for (Mob m : frozen) {
                if (m.isAlive()) Fx.burst(sw, ParticleTypes.SNOWFLAKE, m.getX(), m.getY() + 1, m.getZ(), 2, 0.4, 0.6, 0.4, 0);
            }
            if (t % 4 == 0) {
                Vec3 here = u.position();
                Fx.ring(sw, Pal.GRAY, here.x, here.y + 0.2, here.z, 3 + (t % 20) * 0.6, 36);
            }
        });
        Scheduler.later(101, () -> {
            for (Mob m : frozen) {
                if (m.isAlive()) {
                    m.setNoAi(false);
                    Fx.burst(sw, ParticleTypes.END_ROD, m.getX(), m.getY() + 1, m.getZ(), 10, 0.4, 0.6, 0.4, 0.05);
                }
            }
        });
    }

    static void molassesHour(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 1));
        u.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 200, 1));
        Fx.sound(sw, u.blockPosition(), SoundEvents.PORTAL_AMBIENT, 2f, 0.3f);
        Util.loop(100, 2, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 here = u.position();
            Fx.burst(sw, ParticleTypes.FALLING_HONEY, here.x, here.y + 4, here.z, 12, 8, 1.5, 8, 0);
            Fx.burst(sw, Pal.YELLOW, here.x, here.y + 1, here.z, 4, 8, 1.5, 8, 0);
            if (t % 5 == 0) {
                for (Mob m : Util.foes(sw, here, 20)) {
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 1, false, false));
                }
            }
        });
    }

    static void fastForward(ServerLevel sw, Player u) {
        for (var p : Util.playersNear(sw, u.position(), 10)) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 3));
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 200, 3));
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 2f, 1.8f);
        Util.loop(100, 2, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 dir = Util.flatLook(u).scale(-1);
            for (int i = 0; i < 4; i++) {
                Fx.burst(sw, ParticleTypes.END_ROD, u.getX() + dir.x * i * 0.7, u.getY() + 0.5 + i * 0.2, u.getZ() + dir.z * i * 0.7, 1, 0.2, 0.3, 0.2, 0);
            }
            Fx.burst(sw, Pal.BLUE, u.getX(), u.getY() + 1, u.getZ(), 3, 0.5, 0.6, 0.5, 0);
        });
    }

    static void mirrorStep(ServerLevel sw, Player u) {
        final Vec3 old = u.position();
        Vec3 look = Util.flatLook(u);
        Vec3 side = new Vec3(-look.z, 0, look.x);
        if (sw.random.nextBoolean()) side = side.scale(-1);
        u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20, 4, false, false));
        Util.launch(u, side.x * 1.6, 0.2, side.z * 1.6);
        Fx.sound(sw, u.blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, 2f, 1.0f);
        Util.loop(20, 2, t -> {
            for (double h = 0; h <= 1.8; h += 0.3) {
                Fx.burst(sw, Pal.LAVENDER, old.x, old.y + h, old.z, 1, 0.15, 0, 0.15, 0);
            }
            Fx.burst(sw, ParticleTypes.END_ROD, old.x, old.y + 0.9, old.z, 1, 0.2, 0.5, 0.2, 0.01);
        });
    }

    static void shatterReality(ServerLevel sw, Player u) {
        final Vec3 c = u.position();
        Fx.sound(sw, u.blockPosition(), SoundEvents.GLASS_BREAK, 4f, 0.6f);
        Fx.sound(sw, u.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 2f, 1.5f);
        Fx.screen(sw, c, 64, 1f, 5f, 24, 0xFFFFFF);
        for (Mob m : Util.foes(sw, c, 12)) {
            Util.hurt(sw, u, m, 16f);
            Util.shove(m, c, 1.4, 0.5);
        }
        final int spokes = 10;
        Util.loop(14, 1, t -> {
            double r = t + 1.0;
            for (int s = 0; s < spokes; s++) {
                double a = Math.PI * 2 * s / spokes + Math.sin(s * 7.0) * 0.2;
                double jag = Math.sin(t * 1.7 + s) * 0.4;
                double px = c.x + Math.cos(a) * r + jag;
                double pz = c.z + Math.sin(a) * r + jag;
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, px, c.y + 0.1, pz, 3, 0.1, 0.8, 0.1, 0.2);
                Fx.burst(sw, Pal.WHITE, px, c.y + 0.2, pz, 1, 0, 0, 0, 0);
            }
            Fx.ring(sw, Pal.CREAM, c.x, c.y + 0.2, c.z, r, 48);
        });
    }

    static void realityTear(ServerLevel sw, Player u) {
        final Vec3 c = Util.pick(sw, u, 40).pos();
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_STARE, 3f, 0.5f);
        Util.loop(80, 1, t -> {
            double wob = Math.sin(t * 0.3) * 0.15;
            int n = 0;
            for (double y = -3; y <= 4; y += 0.35) {
                double w = 1 - Math.abs(y - 0.5) / 4.0;
                Fx.burst(sw, Pal.BLACK, c.x + wob, c.y + y, c.z, 1, 0.08 * w, 0, 0.08 * w, 0);
                if (n++ % 3 == 0) {
                    Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, c.x + wob, c.y + y, c.z, 2, 0.4, 0, 0.4, 0.1);
                    Fx.burst(sw, Pal.LAVENDER, c.x + wob + 0.25, c.y + y, c.z, 1, 0, 0, 0, 0);
                }
            }
            if (t % 8 == 0) {
                for (Mob m : Util.foes(sw, c, 6)) {
                    Util.pull(m, c.add(0, 0.5, 0), 0.7);
                    if (m.distanceToSqr(c) < 4) Util.hurt(sw, u, m, 4f);
                }
            }
        });
        Scheduler.later(82, () -> {
            for (Mob m : Util.foes(sw, c, 5)) Util.hurt(sw, u, m, 15f);
            Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, c.x, c.y + 1, c.z, 80, 1, 2, 1, 0.5);
            Fx.burst(sw, ParticleTypes.FLASH, c.x, c.y + 1, c.z, 1, 0, 0, 0, 0);
            Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.GENERIC_EXPLODE, 1.5f, 1.6f);
        });
    }

    static void phaseShift(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 100, 0, false, false));
        u.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 2));
        u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 2));
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 1.6f);
        Util.loop(50, 2, t -> {
            if (Util.gone(sw, u)) return;
            Fx.burst(sw, Pal.LAVENDER, u.getX(), u.getY() + 1, u.getZ(), 5, 0.3, 0.7, 0.3, 0);
            Fx.burst(sw, ParticleTypes.WHITE_ASH, u.getX(), u.getY() + 1, u.getZ(), 5, 0.3, 0.7, 0.3, 0);
        });
    }

    static void intangible(ServerLevel sw, Player u) {
        final UUID id = u.getUUID();
        Imagination.SHIELDED.add(id);
        Fx.sound(sw, u.blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, 2f, 0.6f);
        Util.loop(100, 1, t -> {
            if (Util.gone(sw, u)) {
                Imagination.SHIELDED.remove(id);
                return;
            }
            u.clearFire();
            Fx.sphere(sw, Pal.WHITE, u.position().add(0, 1, 0), 1.3, 8, t * 0.2);
            if (t % 4 == 0) Fx.burst(sw, ParticleTypes.WHITE_ASH, u.getX(), u.getY() + 1, u.getZ(), 4, 0.5, 0.8, 0.5, 0);
        });
        Scheduler.later(102, () -> Imagination.SHIELDED.remove(id));
    }

    static void heavyDream(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 120, 4, false, false));
        Util.launch(u, 0, 1.5, 0);
        final boolean[] landed = {false};
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 2f, 0.5f);
        Util.loop(60, 1, t -> {
            if (landed[0] || Util.gone(sw, u)) return;
            Fx.burst(sw, Pal.LAVENDER, u.getX(), u.getY() + 0.5, u.getZ(), 4, 0.3, 0.3, 0.3, 0);
            Fx.burst(sw, ParticleTypes.CLOUD, u.getX(), u.getY() + 0.5, u.getZ(), 2, 0.3, 0.3, 0.3, 0.02);
            if (t == 14) Util.launch(u, 0, -3.5, 0);
            if (t > 16 && !sw.noCollision(u, u.getBoundingBox().move(0, -0.3, 0))) {
                landed[0] = true;
                u.fallDistance = 0;
                Vec3 c = u.position();
                for (Mob m : Util.foes(sw, c, 8)) {
                    Util.hurt(sw, u, m, 18f);
                    Util.shove(m, c, 1.5, 0.6);
                }
                Fx.sound(sw, u.blockPosition(), SoundEvents.GENERIC_EXPLODE, 2f, 0.5f);
                Fx.screen(sw, c, 40, 0.4f, 6f, 10, 0xFFFFFF);
                Util.loop(10, 1, k -> Fx.ring(sw, Pal.CREAM, c.x, c.y + 0.2, c.z, 1 + k * 0.8, 40));
            }
        });
    }

    static void dreamPearl(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 0.8f);
        Fx.sphere(sw, ParticleTypes.REVERSE_PORTAL, u.position().add(0, 1, 0), 1.2, 30, 0);
        if (!Util.blink(sw, u, 64)) {
            Util.msg(u, "\u00a7cNowhere to land...");
            return;
        }
        Fx.screen(sw, u.position(), 30, 0.5f, 0f, 1, 0xE8E0FF);
        Fx.sphere(sw, Pal.LAVENDER, u.position().add(0, 1, 0), 1.4, 30, 0);
    }
}
