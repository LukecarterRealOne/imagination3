package com.imagine.mod;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;

/** All 73 abilities in one table: name, description (menu tooltip), cooldown in ticks, and the code to run. */
public final class Abilities {
    private Abilities() {}

    @FunctionalInterface
    public interface Power {
        void cast(ServerLevel sw, Player user);
    }

    public record Ability(String name, String desc, int cooldown, Power run) {}

    private static Ability a(String name, String desc, int cooldown, Power run) {
        return new Ability(name, desc, cooldown, run);
    }

    public static final String[] CAT_NAMES = {"Dream", "Liminal", "Creation", "Reality", "Nightmare", "Wonder"};
    /** Index of the first ability of each category. */
    public static final int[] CAT_START = {0, 9, 19, 34, 47, 56};

    public static final Ability[] ALL = {
        a("Daydream", "Drift on slow, sparkling air. Slow falling and gentle regeneration.", 60, PowersA::daydream),
        a("Lucid Sight", "See everything. Night vision, and nearby monsters glow.", 200, PowersA::lucidSight),
        a("Pillow Fort", "A soft dome of cloud. Absorption, resistance, and enemies get nudged away.", 300, PowersA::pillowFort),
        a("Sleepwalk", "Glide along, light as a dream. Speed, jump and slow falling.", 200, PowersA::sleepwalk),
        a("Dream Catcher", "A woven web turns projectiles back for 10 seconds.", 400, PowersA::dreamCatcher),
        a("Wake Up", "Cleanse every bad effect, heal fully, refill hunger.", 300, PowersA::wakeUp),
        a("Cloud Nine", "Conjure a temporary cloud platform under your feet (great mid-air).", 200, PowersA::cloudNine),
        a("Sweet Dreams", "Heal nearby players and friends.", 200, PowersA::sweetDreams),
        a("Petal Rain", "Cherry petals fall and the sky begins to rain. You regenerate.", 300, PowersA::petalRain),
        a("Corridor Step", "Step through the walls of space: a short teleport.", 60, PowersA::corridorStep),
        a("Poolrooms", "A pale-blue shimmering floor. Enemies wade slowly through it.", 300, PowersA::poolrooms),
        a("Backrooms Haze", "Humming yellow fog. Enemies go blind, you speed up.", 300, PowersA::backroomsHaze),
        a("Fluorescent Flicker", "Strobing lights blind and burn nearby enemies.", 200, PowersA::fluorescentFlicker),
        a("Empty Mall", "A hush falls. Nearby enemies are slowed and weakened.", 300, PowersA::emptyMall),
        a("Stairwell Up", "A spiral of light launches you skyward.", 120, PowersA::stairwellUp),
        a("Static", "TV static crackles outward, shocking and confusing enemies.", 160, PowersA::staticBurst),
        a("Take the Exit", "There is always an exit. Teleports you to your bed or world spawn.", 1200, PowersA::takeTheExit),
        a("Deja Vu", "Mark this moment. Five seconds later you snap back here.", 400, PowersA::dejaVu),
        a("Lights Out", "Everything goes dark. Enemies are blinded, you see fine.", 400, PowersA::lightsOut),
        a("Phantom Blades", "Eight spectral blades orbit you and slice nearby enemies.", 200, PowersB::phantomBlades),
        a("Imagine Bridge", "A glass bridge grows ahead of you.", 100, PowersB::imagineBridge),
        a("Imagine Staircase", "A stairway to nowhere builds itself upward.", 100, PowersB::imagineStaircase),
        a("Imagine Wall", "Summon a temporary glass wall in front of you.", 100, PowersB::imagineWall),
        a("Imagine Tower", "Grow a pillar beneath your feet and rise with it.", 200, PowersB::imagineTower),
        a("Imagine Dome", "A glass dome surrounds you for 20 seconds.", 400, PowersB::imagineDome),
        a("Imagine Sun", "Tiny suns of light hang in the air around you.", 400, PowersB::imagineSun),
        a("Imagine Garden", "Bone-meal everything growing around you.", 200, PowersB::imagineGarden),
        a("Imagine Feast", "Floating food. Restores hunger and saturation.", 300, PowersB::imagineFeast),
        a("Imagine Anything", "Random items from every installed mod rain from the sky.", 300, PowersB::imagineAnything),
        a("Imagine Armor", "Big absorption and resistance for a minute.", 600, PowersB::imagineArmor),
        a("Imaginary Friend", "A loyal tamed wolf appears for a minute.", 600, PowersB::imaginaryFriend),
        a("Imaginary Army", "Iron and snow golems fight for you for a minute.", 1200, PowersB::imaginaryArmy),
        a("Rainbow Bridge", "A seven-lane rainbow road, built as you watch.", 200, PowersB::rainbowBridge),
        a("Dream Moon", "A pale moon hangs overhead, healing and lighting the way.", 600, PowersB::dreamMoon),
        a("Gravity Flip", "Hurl enemies skyward, then slam them back down.", 200, PowersB::gravityFlip),
        a("Warp Pull", "Drag every nearby enemy toward you.", 200, PowersB::warpPull),
        a("Reality Shove", "A shockwave hurts and shoves enemies away.", 120, PowersB::realityShove),
        a("Stillness", "Freeze enemies in place for five seconds.", 400, PowersB::stillness),
        a("Molasses Hour", "Time thickens. Enemies crawl, you move fast.", 400, PowersB::molassesHour),
        a("Fast Forward", "You and nearby players get a big speed and haste boost.", 400, PowersB::fastForward),
        a("Mirror Step", "Sidestep with a ghostly afterimage and a moment of invulnerability.", 60, PowersB::mirrorStep),
        a("Shatter Reality", "Cracks spread across the ground, damaging everything.", 200, PowersB::shatterReality),
        a("Reality Tear", "Open a slit in the world that drags enemies in.", 300, PowersB::realityTear),
        a("Phase Shift", "Turn invisible and fast for a few seconds.", 200, PowersB::phaseShift),
        a("Intangible", "Nothing can hurt you for 5 seconds.", 600, PowersB::intangible),
        a("Heavy Dream", "Leap up, then slam down in a shockwave.", 200, PowersB::heavyDream),
        a("Dream Pearl", "Long-range teleport to where you look.", 100, PowersB::dreamPearl),
        a("Nightmare Beam", "A dark spiral beam that withers whatever it touches.", 200, PowersC::nightmareBeam),
        a("Sleep Paralysis", "Lock an enemy in place while shadows crawl over it.", 300, PowersC::sleepParalysis),
        a("Shadow Hands", "Hands of shadow reach up and grab the nearest enemies.", 300, PowersC::shadowHands),
        a("Whispers", "Unseen voices make enemies glow and weaken.", 300, PowersC::whispers),
        a("The Stalker", "A tall silent figure follows you and hunts your enemies.", 1200, PowersC::theStalker),
        a("Fear Aura", "Nearby enemies panic and run away.", 300, PowersC::fearAura),
        a("Uncanny Smile", "A wrong little smile appears above enemies as they wither.", 300, PowersC::uncannySmile),
        a("Echo Pulse", "Four expanding sonic pulses ripple outward.", 200, PowersC::echoPulse),
        a("Dread Verdict", "Execute a weakened target. A heavy blow to healthy ones.", 200, PowersC::dreadVerdict),
        a("Starfall", "Fourteen stars streak down around where you look.", 300, PowersC::starfall),
        a("Aurora", "Ribbons of colour fill the sky. Regeneration and speed for you and friends.", 600, PowersC::aurora),
        a("Dream Lightning", "Pastel lightning strikes where you aim.", 200, PowersC::dreamLightning),
        a("Comet", "A comet falls from the sky onto your target.", 300, PowersC::comet),
        a("Bubble Prison", "Trap enemies in floating bubbles, then pop them.", 300, PowersC::bubblePrison),
        a("Petal Storm", "A whirl of petals cuts through anything close.", 300, PowersC::petalStorm),
        a("Spore Dream", "A drifting cloud of spores poisons enemies and heals you.", 300, PowersC::sporeDream),
        a("Lullaby", "A soft song: enemies forget to attack for 10 seconds.", 400, PowersC::lullaby),
        a("Make a Wish", "Three random beneficial effects for a minute.", 1200, PowersC::makeAWish),
        a("Confetti Blast", "A burst of colour that hurts and shoves.", 100, PowersC::confettiBlast),
        a("Phantom Orchestra", "Music swirls around you. Allies speed up, enemies drag.", 400, PowersC::phantomOrchestra),
        a("Memory Anchor", "Cast once to save this spot, cast again to return to it.", 100, PowersC::memoryAnchor),
        a("Epiphany", "A flash of insight: experience, luck and a full heal.", 1200, PowersC::epiphany),
        a("Supernova", "Charge up, then detonate a huge expanding shell of light.", 1200, PowersC::supernova),
        a("Kaleidoscope", "Spinning rings of colour confuse and slow enemies.", 300, PowersC::kaleidoscope),
        a("Lucid Dream", "You know you are dreaming: a full set of strong buffs.", 1200, PowersC::lucidDream),
        a("Wild Imagination", "Seven random wonders, one after another.", 1200, PowersC::wildImagination)
    };

    public static final int COUNT = ALL.length;

    public static int catEnd(int cat) {
        return cat + 1 < CAT_START.length ? CAT_START[cat + 1] : COUNT;
    }
}
