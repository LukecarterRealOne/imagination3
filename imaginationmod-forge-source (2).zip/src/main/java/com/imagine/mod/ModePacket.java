package com.imagine.mod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/** Server -> all clients: "this player is now in this mode" (-1 = none). */
public class ModePacket {
    public final UUID id;
    public final int mode;

    public ModePacket(UUID id, int mode) {
        this.id = id;
        this.mode = mode;
    }

    public static void encode(ModePacket m, FriendlyByteBuf buf) {
        buf.writeUUID(m.id);
        buf.writeInt(m.mode);
    }

    public static ModePacket decode(FriendlyByteBuf buf) {
        return new ModePacket(buf.readUUID(), buf.readInt());
    }

    public static void handle(ModePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientModes.set(m.id, m.mode)));
        ctx.get().setPacketHandled(true);
    }
}
