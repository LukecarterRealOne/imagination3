package com.imagine.mod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server.
 * action 0 = switch to `mode` (-1 = aura off).
 * action 1 = cast `ability` (-1 = random).
 */
public class SelectPacket {
    public final int mode;
    public final int ability;
    public final int action;

    public SelectPacket(int mode, int ability, int action) {
        this.mode = mode;
        this.ability = ability;
        this.action = action;
    }

    public static void encode(SelectPacket m, FriendlyByteBuf buf) {
        buf.writeInt(m.mode);
        buf.writeInt(m.ability);
        buf.writeInt(m.action);
    }

    public static SelectPacket decode(FriendlyByteBuf buf) {
        return new SelectPacket(buf.readInt(), buf.readInt(), buf.readInt());
    }

    public static void handle(SelectPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sender = ctx.get().getSender();
            if (sender != null) {
                Imagination.onSelect(sender, m.mode, m.ability, m.action);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
